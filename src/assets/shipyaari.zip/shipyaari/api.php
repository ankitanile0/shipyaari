<?php

class ControllerShipyaariApi extends Controller {

	private $debugIt = false;
	
	/*
	* Get products
	*/
	public function products() {

		$this->checkPlugin();

		$this->load->model('catalog/product');
	
		$json = array('success' => true, 'products' => array());

		/*check category id parameter*/
		if (isset($this->request->get['category'])) {
			$category_id = $this->request->get['category'];
		} else {
			$category_id = 0;
		}

		$products = $this->model_catalog_product->getProducts(array(
			'filter_category_id'        => $category_id
		));
		//print_r($products);

		foreach ($products as $product) {

			if ($product['image']) {
				$image = $product['image'];
			} else {
				$image = false;
			}

            if ((float)$product['special']) {
				$special =$this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax'));
			} else {
				$special = false;
			}

			$json['products'][] = array(
					'id'			=> $product['product_id'],
					'name'			=> $product['name'],
					'description'	=> $product['description'],
					'pirce'			=> $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax')),
					'href'			=> $this->url->link('product/product', 'product_id=' . $product['product_id']),
					'thumb'			=> $image,
					'special'		=> $special,
					'rating'		=> $product['rating']
			);
		}

		if ($this->debugIt) {
			echo '<pre>';
			print_r($json);
			echo '</pre>';
		} else {
			$this->response->setOutput(json_encode($json));
		}
	}
		

	/*
	* Get orders
	*/
	public function orders() {

		$this->checkPlugin();
	
		$orderData['orders'] = array();

		$this->load->model('account/order');

		/*check offset parameter*/
		if (isset($this->request->get['offset']) && $this->request->get['offset'] != "" && ctype_digit($this->request->get['offset'])) {
			$offset = $this->request->get['offset'];
		} else {
			$offset 	= 0;
		}

		if (isset($this->request->get['date']) && $this->request->get['date'] != "") {
			$date = urldecode($this->request->get['date']);
		} else {
			$date 	= '2021-02-25 00:00:00';
		}

		/*check limit parameter*/
		if (isset($this->request->get['limit']) && $this->request->get['limit'] != "" && ctype_digit($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit 	= 10000;
		}
		
		/*get all orders of user*/
		
    	if ($offset < 0) {
    		$offset = 0;
    	}
    	
    	if ($limit < 1) {
    		$limit = 1;
    	}	
    	
    	$query = $this->db->query("SELECT o.*,ocp.*,op.*,os.name as status,o.date_added as order_date FROM `" . DB_PREFIX . "order` o INNER JOIN " . DB_PREFIX . "order_product ocp on ocp.order_id = o.order_id INNER JOIN " . DB_PREFIX . "product op ON op.`product_id` = ocp.product_id LEFT JOIN " . DB_PREFIX . "order_status os ON (o.order_status_id = os.order_status_id) WHERE o.order_status_id > '0' AND os.language_id = '" . (int)$this->config->get('config_language_id') . "' AND o.date_added >= '".$date."' ORDER BY o.order_id DESC LIMIT " . (int)$offset . "," . (int)$limit);


    	$results = $query->rows;
    	//print_r($results);

    	$order_array=array();
    	$count=0; $data="";
    	foreach ($results as $key) {

    		//bind products
    		$K = $key['order_id'];
            if (in_array($K, $order_array))
            {
            	$order_array_count = count($order_array) - 1;
            	$product_details =  array(
	    			'order_product_id'=> $key['order_product_id'],
	            	'product_id'=> $key['product_id'],
	            	'name'=> $key['name'],
	            	'model'=> $key['model'],
	            	'quantity'=> $key['quantity'],
	            	'price'=> $key['price'],
	            	'tax'=> $key['tax'],
	            	'reward'=> $key['reward'],
	            	'sku'=> $key['sku'],
	            	'upc'=> $key['upc'],
	            	'ean'=> $key['ean'],
	            	'jan'=> $key['jan'],
	            	'isbn'=> $key['isbn'],
	            	'mpn'=> $key['mpn'],
	            	'location'=> $key['location'],
	            	'stock_status_id'=> $key['stock_status_id'],
	            	'image'=> $key['image'],
	            	'manufacturer_id'=> $key['manufacturer_id'],
	            	'shipping'=> $key['shipping'],
	            	'weight'=> $key['weight'],
	            	'weight_class_id'=> $key['weight_class_id'],
	            	'length'=> $key['length'],
	            	'width'=> $key['width'],
	            	'height'=> $key['height'],
	            	'length_class_id'=> $key['length_class_id'],
	            	'subtract'=> $key['subtract'],
	            	'minimum'=> $key['minimum'],
	            	'sort_order'=> $key['sort_order']
	    			);
            	$datas[$count]["product_details"][] = $product_details;
            	$datas[$count]["total"] = $datas[$count]["total"] + $key['price'];
            	if($order_array_count == $count){$count=0;}else{$count++;}

            }else{
            	$order_array[]=$K;
            	$datas[] = array("order_id" => $key['order_id'],
	    		'invoice_no' => $key['invoice_no'],
	    		'invoice_prefix'=> $key['invoice_prefix'],
	    		'store_name'=> $key['store_name'],
	    		'customer_id'=> $key['customer_id'],
	    		'customer_group_id'=> $key['customer_group_id'],
	    		'firstname'=> $key['firstname'],
	    		'lastname'=> $key['lastname'],
	    		'email'=> $key['email'],
	    		'telephone'=> $key['telephone'],
	    		'custom_field'=> $key['custom_field'],
	    		'payment_firstname'=> $key['payment_firstname'],
	    		'payment_lastname'=> $key['payment_lastname'],
	    		'payment_company'=> $key['payment_company'],
	    		'payment_address_1'=> $key['payment_address_1'],
	    		'payment_address_2'=> $key['payment_address_2'],
	    		'payment_city'=> $key['payment_city'],
	    		'payment_postcode'=> $key['payment_postcode'],
	    		'payment_country'=> $key['payment_country'],
	    		'payment_country_id'=> $key['payment_country_id'],
	    		'payment_zone'=> $key['payment_zone'],
	    		'payment_zone_id'=> $key['payment_zone_id'],
	    		'payment_address_format'=> $key['payment_address_format'],
	    		'payment_custom_field'=> $key['payment_custom_field'],
	    		'payment_method'=> $key['payment_method'],
	    		'payment_code'=> $key['payment_code'],
	    		'shipping_firstname'=> $key['shipping_firstname'],
	    		'shipping_lastname'=> $key['shipping_lastname'],
	    		'shipping_company'=> $key['shipping_company'],
	    		'shipping_address_1'=> $key['shipping_address_1'],
	    		'shipping_address_2'=> $key['shipping_address_2'],
	    		'shipping_city'=> $key['shipping_city'],
	    		'shipping_postcode'=> $key['shipping_postcode'],
	    		'shipping_country'=> $key['shipping_country'],
	    		'shipping_country_id'=> $key['shipping_country_id'],
	    		'shipping_zone'=> $key['shipping_zone'],
	    		'shipping_zone_id'=> $key['shipping_zone_id'],
	    		'shipping_address_format'=> $key['shipping_address_format'],
	    		'shipping_custom_field'=> $key['shipping_custom_field'],
	    		'shipping_method'=> $key['shipping_method'],
	    		'shipping_code'=> $key['shipping_code'],
	    		'comment'=> $key['comment'],
	    		'total'=> $key['total'],
	    		'order_status_id'=> $key['order_status_id'],
	    		'affiliate_id'=> $key['affiliate_id'],
	    		'commission'=> $key['commission'],
	    		'marketing_id'=> $key['marketing_id'],
	    		'tracking'=> $key['tracking'],
	    		'language_id'=> $key['language_id'],
	    		'currency_id'=> $key['currency_id'],
	    		'currency_code'=> $key['currency_code'],
	    		'currency_value'=> $key['currency_value'],
	    		'ip'=> $key['ip'],
	    		'date_added'=> $key['order_date'],
	    		'status'=> $key['status'],
	    		'product_details' => array(array(
	    			'order_product_id'=> $key['order_product_id'],
	            	'product_id'=> $key['product_id'],
	            	'name'=> $key['name'],
	            	'model'=> $key['model'],
	            	'quantity'=> $key['quantity'],
	            	'price'=> $key['price'],
	            	'tax'=> $key['tax'],
	            	'reward'=> $key['reward'],
	            	'sku'=> $key['sku'],
	            	'upc'=> $key['upc'],
	            	'ean'=> $key['ean'],
	            	'jan'=> $key['jan'],
	            	'isbn'=> $key['isbn'],
	            	'mpn'=> $key['mpn'],
	            	'location'=> $key['location'],
	            	'stock_status_id'=> $key['stock_status_id'],
	            	'image'=> $key['image'],
	            	'manufacturer_id'=> $key['manufacturer_id'],
	            	'shipping'=> $key['shipping'],
	            	'weight'=> $key['weight'],
	            	'weight_class_id'=> $key['weight_class_id'],
	            	'length'=> $key['length'],
	            	'width'=> $key['width'],
	            	'height'=> $key['height'],
	            	'length_class_id'=> $key['length_class_id'],
	            	'subtract'=> $key['subtract'],
	            	'minimum'=> $key['minimum'],
	            	'sort_order'=> $key['sort_order']
	            		),
	    			),
             	);
            }


    	}
		
		$orders = array();

		if(count($results)){
			$json['success'] 	= true;
			$json['orders'] 	= $datas;
		}else {
			$json['success'] 	= false;
			$json['msg'] 	= "No orders found";
		}
		
		if ($this->debugIt) {
			echo '<pre>';
			print_r($json);
			echo '</pre>';

		} else {
			$this->response->setOutput(json_encode($json));
		}
	}

	public function orders_status() {

		$this->checkPlugin();
	
		$orderData['orders_status'] = array();

		$this->load->model('account/order');

		/*check offset parameter*/
		if (isset($this->request->get['order_id']) && $this->request->get['order_id'] != "") {
			$order_id = $this->request->get['order_id'];
			$query = $this->db->query("SELECT o.*,os.name as status FROM `" . DB_PREFIX . "order` o LEFT JOIN " . DB_PREFIX . "order_status os ON (o.order_status_id = os.order_status_id) WHERE o.order_status_id > '0' AND order_id = '".$order_id."'");	

	    	$results = $query->rows;
	    	if(count($results)){
	    		$update = $this->db->query("UPDATE " . DB_PREFIX . "order SET order_status_id = '5' WHERE order_id = '".$order_id."'");
	    		$json['success'] 	= true;
				$json['msg'] 	= 'order id status updated';
	    	}else{
	    		$json['success'] 	= false;
				$json['msg'] 	= 'order id not found';
	    	}
		} else {
			$json['success'] 	= false;
			$json['msg'] 	= 'order id is empty';
		}
		
		if ($this->debugIt) {
			echo '<pre>';
			print_r($json);
			echo '</pre>';

		} else {
			$this->response->setOutput(json_encode($json));
		}
	}


	
	
	private function checkPlugin() {

		$json = array("success"=>false,"msg"=>"check details");
		
		if(isset($this->request->get['key']) && isset($this->request->get['username'])){
		    if(!empty($this->request->get['key']) && !empty($this->request->get['username'])){
		        $key = $this->request->get['key'];
        	    $check = $this->db->query("SELECT * FROM `" . DB_PREFIX . "api` a WHERE username='".$this->request->get['username']."' AND status = '1'");	
            	$results_check = $check->rows;
              	if(count($results_check)<1){$json["error"] = 'Invalid username';}else{$key_real= $results_check[0]['key']; if($key_real != $key){$json["error"] = 'Invalid secret key';}}
		    }else{$json["error"] = 'please enter value in all required parameters';}
		}else{$json["error"] = 'please add all required parameters';}
		
		if(isset($json["error"])){
			$this->response->addHeader('Content-Type: application/json');
			echo(json_encode($json));
			exit;
		}else {
			$this->response->setOutput(json_encode($json));			
		}	
	}	

}
